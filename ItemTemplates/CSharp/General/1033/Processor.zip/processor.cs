﻿// -----------------------------------------------------------------------
// <copyright file="$safeitemrootname$.cs" company="$registeredorganization$">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace $rootnamespace$
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.Diagnostics;
	$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
	$endif$using Abc.Processor;

	partial class $safeitemrootname$: Processor
	{
		public $safeitemrootname$()
		{
			InitializeComponent();
		}

		protected override void OnStart() {
		{
			// TODO: Add code here to start your processor.
		}
	}
}
